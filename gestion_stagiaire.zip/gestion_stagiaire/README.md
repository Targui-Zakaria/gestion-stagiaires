# Gestion des Stagiaires

Système de gestion des stagiaires avec gestion des encadrants et évaluations.

## Fonctionnalités

### 👨‍💼 Interface Admin
- Gestion complète des stagiaires (ajout, modification, suppression)
- Gestion des encadrants
- Gestion des types de stage
- Accès à toutes les données

### 👨‍🏫 Interface Encadrant
- Consultation des stagiaires assignés
- Évaluation des stagiaires (développement et ponctualité)
- Accès limité aux données

## Comptes de connexion

### 🔐 Admin
- **Username:** `admin`
- **Password:** `admin123`
- **URL:** `/admin/` (interface Django admin)

### 👨‍🏫 Encadrants
Chaque encadrant a son propre compte avec accès à ses stagiaires assignés :

| Encadrant | Username | Password | Email |
|------------|----------|----------|-------|
| Achraf     | `achraf` | `achraf123` | achraf@example.com |
| Rachid     | `rachid` | `rachid123` | rachid@example.com |
| Amin       | `amin`   | `amin123`   | amin@example.com |
| Iness      | `iness`  | `iness123`  | iness@example.com |
| Ayman      | `ayman`  | `ayman123`  | ayman@example.com |

## Utilisation

### 1. Connexion Admin
- Allez sur `/admin/`
- Connectez-vous avec `admin` / `admin123`
- Gérez les stagiaires, encadrants et types de stage

### 2. Connexion Encadrant
- Allez sur `/connexion/`
- Choisissez le formulaire "Encadrant"
- Connectez-vous avec vos identifiants
- Vous verrez uniquement vos stagiaires assignés

### 3. Gestion des Stagiaires
- **Admin :** Peut assigner n'importe quel encadrant à un stagiaire
- **Encadrant :** Peut consulter et évaluer ses stagiaires

## Structure de la base de données

### Modèles principaux
- **Stagiaire** : Informations du stagiaire avec encadrant assigné
- **Encadrant** : Profils des encadrants
- **Evaluation** : Notes et commentaires sur les stagiaires
- **TypeStage** : Types de stage disponibles

### Relations
- Un stagiaire a un encadrant (obligatoire)
- Un encadrant peut avoir plusieurs stagiaires
- Un stagiaire peut avoir plusieurs évaluations

## Sécurité
- Chaque encadrant ne voit que ses stagiaires
- Permissions basées sur les groupes Django
- Authentification requise pour toutes les opérations

## Démarrage rapide

1. **Installer les dépendances :**
   ```bash
   pip install -r requirements.txt
   ```

2. **Appliquer les migrations :**
   ```bash
   python manage.py migrate
   ```

3. **Créer un superutilisateur (optionnel) :**
   ```bash
   python manage.py createsuperuser
   ```

4. **Lancer le serveur :**
   ```bash
   python manage.py runserver
   ```

5. **Accéder à l'application :**
   - Interface principale : `http://localhost:8000/`
   - Admin Django : `http://localhost:8000/admin/`

## Notes importantes

- Les mots de passe par défaut doivent être changés en production
- Les emails des encadrants sont fictifs (example.com)
- Le système utilise SQLite par défaut (peut être changé vers PostgreSQL/MySQL)

