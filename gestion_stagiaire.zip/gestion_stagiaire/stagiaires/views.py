from django.shortcuts import render, redirect, get_object_or_404
from .models import Stagiaire, Encadrant, Evaluation
from .forms import StagiaireForm, EvaluationForm, EncadrantForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User, Permission
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.contrib import messages
from django.utils import timezone
from django.http import HttpResponse
import logging
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from io import BytesIO
@login_required
def liste_stagiaires(request):
    stagiaires = Stagiaire.objects.filter(archived_at__isnull=True)
    return render(request, 'stagiaires/liste.html', {'stagiaires': stagiaires})


@login_required
def home_redirect(request):
    if request.user.has_perm('stagiaires.add_stagiaire'):
        return redirect('dashboard_admin')
    elif request.user.has_perm('stagiaires.add_evaluation'):
        return redirect('dashboard_encadrant')
    else:
        return redirect('page_acces_refuse')


@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def dashboard_admin(request):
    # Vérifier que l'utilisateur n'a PAS les permissions d'encadrant pour éviter les conflits
    if not request.user.has_perm('stagiaires.add_stagiaire'):
        return redirect('page_acces_refuse')
    
    stagiaires = Stagiaire.objects.filter(archived_at__isnull=True)
    return render(request, 'stagiaires/admin_dashboard.html', {'stagiaires': stagiaires})


@permission_required('stagiaires.add_evaluation', raise_exception=True)
def dashboard_encadrant(request):
    # Vérifier que l'utilisateur n'a PAS les permissions d'admin pour éviter les conflits
    # Autoriser un admin à voir le tableau encadrant s'il s'est connecté via le formulaire encadrant
    login_as = request.session.get('login_as')
    if request.user.has_perm('stagiaires.add_stagiaire') and login_as != 'encadrant':
        return redirect('dashboard_admin')
    
    # Récupérer l'encadrant lié à l'utilisateur connecté
    try:
        encadrant = Encadrant.objects.get(email=request.user.email)
        # Filtrer les stagiaires pour n'afficher que ceux actifs (non archivés et non terminés)
        today = timezone.now().date()
        stagiaires = Stagiaire.objects.filter(
            encadrant=encadrant,
            archived_at__isnull=True,
            date_fin__gte=today,
        )
    except Encadrant.DoesNotExist:
        # Si l'encadrant n'existe pas, afficher un message d'erreur
        stagiaires = []
        encadrant = None
    
    return render(request, 'stagiaires/encadrant_dashboard.html', {
        'stagiaires': stagiaires,
        'encadrant': encadrant
    })

@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def ajouter_stagiaire(request):
    if request.method == 'POST':
        form = StagiaireForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('liste_stagiaires')
    else:
        form = StagiaireForm()
    return render(request, 'stagiaires/ajouter.html', {'form': form})

@permission_required('stagiaires.change_stagiaire', raise_exception=True)
def modifier_stagiaire(request, id):
    stagiaire = get_object_or_404(Stagiaire, id=id)
    if request.method == 'POST':
        form = StagiaireForm(request.POST, instance=stagiaire)
        if form.is_valid():
            form.save()
            return redirect('liste_stagiaires')
    else:
        form = StagiaireForm(instance=stagiaire)
    return render(request, 'stagiaires/ajouter.html', {'form': form})

@permission_required('stagiaires.delete_stagiaire', raise_exception=True)
def supprimer_stagiaire(request, id):
    stagiaire = get_object_or_404(Stagiaire, id=id)
    stagiaire.archive()
    return redirect('liste_stagiaires')

@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def liste_encadrants(request):
    encadrants = Encadrant.objects.all().order_by('nom', 'prenom')
    return render(request, 'stagiaires/liste_encadrants.html', {'encadrants': encadrants})

@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def ajouter_encadrant(request):
    if request.method == 'POST':
        form = EncadrantForm(request.POST)
        if form.is_valid():
            encadrant = form.save()
            # Créer l'utilisateur lié (encadrant)
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password')
            email = encadrant.email
            user = User.objects.create_user(username=username, email=email, password=raw_password)
            # Donner uniquement la permission d'évaluer (pas admin)
            try:
                perm = Permission.objects.get(codename='add_evaluation')
                user.user_permissions.add(perm)
            except Permission.DoesNotExist:
                pass
            return redirect('liste_encadrants')
    else:
        form = EncadrantForm()
    return render(request, 'stagiaires/ajouter_encadrant.html', {'form': form})

@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def modifier_encadrant(request, id):
    encadrant = get_object_or_404(Encadrant, id=id)
    today = timezone.now().date()
    stagiaires_actuels = Stagiaire.objects.filter(
        encadrant=encadrant,
        archived_at__isnull=True,
        date_fin__gte=today,
    ).order_by('prenom', 'nom')
    if request.method == 'POST':
        form = EncadrantForm(request.POST, instance=encadrant)
        if form.is_valid():
            encadrant = form.save()
            # Si un mot de passe est fourni, créer/mettre à jour le compte utilisateur lié
            new_password = form.cleaned_data.get('password')
            if new_password:
                try:
                    user = User.objects.get(email=encadrant.email)
                except User.DoesNotExist:
                    # Créer un user si inexistant
                    base = (encadrant.email.split('@')[0] if encadrant.email else f"{encadrant.prenom}{encadrant.nom}").lower()
                    candidate = base or "encadrant"
                    suffix = 1
                    while User.objects.filter(username=candidate).exists():
                        candidate = f"{base}{suffix}"
                        suffix += 1
                    user = User.objects.create_user(username=candidate, email=encadrant.email or "", password=new_password)
                    try:
                        perm = Permission.objects.get(codename='add_evaluation')
                        user.user_permissions.add(perm)
                    except Permission.DoesNotExist:
                        pass
                else:
                    user.set_password(new_password)
                    user.save()
            return redirect('liste_encadrants')
    else:
        form = EncadrantForm(instance=encadrant)
    return render(request, 'stagiaires/ajouter_encadrant.html', {
        'form': form, 
        'encadrant': encadrant,
        'modifier': True,
        'stagiaires_actuels': stagiaires_actuels,
    })

@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def supprimer_encadrant(request, id):
    encadrant = get_object_or_404(Encadrant, id=id)
    stagiaires_associes = Stagiaire.objects.filter(encadrant=encadrant)
    
    if request.method == 'POST':
        if stagiaires_associes.exists():
            # Impossible de supprimer
            pass
        else:
            encadrant.delete()
        return redirect('liste_encadrants')
    
    return render(request, 'stagiaires/supprimer_encadrant.html', {
        'encadrant': encadrant,
        'stagiaires_associes': stagiaires_associes
    })

def connexion_view(request):
    return render(request, 'stagiaires/login.html')


def connexion_admin(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user and user.has_perm('stagiaires.add_stagiaire'):
            login(request, user)
            return redirect('dashboard_admin')
        else:
            return render(request, 'stagiaires/login.html', {'error': "Accès refusé. Vérifiez vos identifiants et vos permissions Admin."})
    return redirect('connexion')


def connexion_encadrant(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if not user:
            return render(request, 'stagiaires/login.html', {
                'error': "Identifiants incorrects."
            })
        # Vérifier que l'utilisateur correspond à un encadrant existant (via email)
        try:
            encadrant = Encadrant.objects.get(email=user.email)
        except Encadrant.DoesNotExist:
            return render(request, 'stagiaires/login.html', {
                'error': "Accès refusé. Cet utilisateur n'est pas reconnu comme encadrant."
            })
        # S'assurer que l'utilisateur possède la permission d'évaluation, sinon l'ajouter
        if not user.has_perm('stagiaires.add_evaluation'):
            try:
                perm = Permission.objects.get(codename='add_evaluation')
                user.user_permissions.add(perm)
            except Permission.DoesNotExist:
                return render(request, 'stagiaires/login.html', {
                    'error': "Permission d'encadrant manquante. Contactez l'administrateur."
                })
        login(request, user)
        # Marquer la session comme 'connexion encadrant'
        request.session['login_as'] = 'encadrant'
        return redirect('dashboard_encadrant')
    return redirect('connexion')

def deconnexion_view(request):
    logout(request)
    return redirect('connexion')

@permission_required('stagiaires.add_evaluation', raise_exception=True)
def evaluer_stagiaire(request, id):
    stagiaire = get_object_or_404(Stagiaire, id=id)
    if request.method == 'POST':
        form = EvaluationForm(request.POST)
        if form.is_valid():
            evaluation = form.save(commit=False)
            evaluation.stagiaire = stagiaire
            evaluation.evaluator = request.user
            evaluation.save()
            return redirect('fiche_evaluation', id=evaluation.id)
    else:
        form = EvaluationForm()
    return render(request, 'stagiaires/evaluer.html', {'form': form, 'stagiaire': stagiaire})


@login_required
def fiche_evaluation(request, id):
    evaluation = get_object_or_404(Evaluation, id=id)
    return render(request, 'stagiaires/fiche_evaluation.html', {
        'evaluation': evaluation,
        'stagiaire': evaluation.stagiaire,
    })


@login_required
def export_evaluation_pdf(request, id):
    evaluation = get_object_or_404(Evaluation, id=id)
    stagiaire = evaluation.stagiaire
    
    # Utiliser un buffer mémoire pour générer le PDF en toute sécurité
    pdf_buffer = BytesIO()
    filename = f"evaluation_{stagiaire.prenom}_{stagiaire.nom}_{evaluation.created_at.strftime('%Y%m%d')}.pdf"
    
    # Préparer le document PDF
    doc = SimpleDocTemplate(pdf_buffer, pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()
    
    # Titre principal
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=18,
        spaceAfter=30,
        alignment=1  # Centré
    )
    elements.append(Paragraph("FICHE D'ÉVALUATION DE STAGE", title_style))
    elements.append(Spacer(1, 20))
    
    # Informations du stagiaire
    info_data = [
        ['Stagiaire', f"{stagiaire.prenom} {stagiaire.nom}"],
        ['Encadrant', f"{stagiaire.encadrant.prenom} {stagiaire.encadrant.nom}"],
        ['Date d\'évaluation', evaluation.created_at.strftime("%d/%m/%Y %H:%M")],
        ['Évaluateur', evaluation.evaluator.username if evaluation.evaluator else "—"],
        ['Sujet du stage', stagiaire.sujet_stage],
        ['Période', f"Du {stagiaire.date_debut.strftime('%d/%m/%Y')} au {stagiaire.date_fin.strftime('%d/%m/%Y')}"],
    ]
    
    info_table = Table(info_data, colWidths=[4*cm, 12*cm])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.grey),
        ('TEXTCOLOR', (0, 0), (0, -1), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
        ('BACKGROUND', (1, 0), (-1, -1), colors.beige),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    elements.append(info_table)
    elements.append(Spacer(1, 20))
    
    # Section 1: Réalisation du projet
    elements.append(Paragraph("1. RÉALISATION DU PROJET", styles['Heading2']))
    elements.append(Spacer(1, 10))
    
    dev_data = [
        ['Critère', 'Note /5'],
        ['Méthodologie adaptée', str(evaluation.methodologie)],
        ['Connaissances techniques', str(evaluation.connaissances_techniques)],
        ['Utilisation des outils', str(evaluation.outils_logiciels)],
        ['Solutions adaptées', str(evaluation.solutions_problemes)],
        ['Atteinte des objectifs', str(evaluation.objectifs_projet)],
        ['', ''],
        ['Moyenne réalisation du projet', f"{evaluation.realisation_projet_score}/5"],
    ]
    
    dev_table = Table(dev_data, colWidths=[12*cm, 4*cm])
    dev_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 1), (1, -2), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, -2), (-1, -2), colors.lightgrey),
        ('FONTNAME', (0, -2), (-1, -2), 'Helvetica-Bold'),
    ]))
    elements.append(dev_table)
    elements.append(Spacer(1, 20))
    
    # Section 2: Attitude & comportement
    elements.append(Paragraph("2. ATTITUDE & COMPORTEMENT", styles['Heading2']))
    elements.append(Spacer(1, 10))
    
    att_data = [
        ['Critère', 'Note /5'],
        ['Adaptation et détermination', str(evaluation.adaptation_determination)],
        ['Documentation et recherche', str(evaluation.documentation_recherche)],
        ['Contacts avec collaborateurs', str(evaluation.contacts_collaborateurs)],
        ['Initiatives et créativité', str(evaluation.initiatives_creativite)],
        ['Expression des idées', str(evaluation.expression_idees)],
        ['Critiques constructives', str(evaluation.critiques_corrections)],
        ['', ''],
        ['Moyenne attitude & comportement', f"{evaluation.attitude_comportement_score}/5"],
    ]
    
    att_table = Table(att_data, colWidths=[12*cm, 4*cm])
    att_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('ALIGN', (1, 1), (1, -2), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('BACKGROUND', (0, -2), (-1, -2), colors.lightgrey),
        ('FONTNAME', (0, -2), (-1, -2), 'Helvetica-Bold'),
    ]))
    elements.append(att_table)
    elements.append(Spacer(1, 20))
    
    # Score global
    elements.append(Paragraph(f"Score global sur 20: {evaluation.score_sur_20}", styles['Heading3']))
    elements.append(Spacer(1, 20))
    
    # Commentaire
    if evaluation.comment:
        elements.append(Paragraph("Commentaire général:", styles['Heading3']))
        elements.append(Spacer(1, 10))
        elements.append(Paragraph(evaluation.comment, styles['Normal']))
        elements.append(Spacer(1, 20))
    
    # Date et signature
    elements.append(Paragraph(f"Fait le : {evaluation.created_at.strftime('%d/%m/%Y')}", styles['Normal']))
    elements.append(Spacer(1, 30))
    elements.append(Paragraph("Signature de l'encadrant:", styles['Normal']))
    elements.append(Spacer(1, 20))
    elements.append(Paragraph("_" * 50, styles['Normal']))
    
    # Générer le PDF avec gestion d'erreurs
    try:
        doc.build(elements)
        pdf_value = pdf_buffer.getvalue()
    except Exception as exc:
        logging.exception("Erreur lors de la génération du PDF d'évaluation")
        messages.error(request, "Une erreur est survenue lors de la génération du PDF. Veuillez réessayer plus tard.")
        return redirect('fiche_evaluation', id=evaluation.id)
    finally:
        pdf_buffer.close()

    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="{filename}"'
    response.write(pdf_value)
    return response


@login_required
def details_stagiaire(request, id):
    stagiaire = get_object_or_404(Stagiaire, id=id)
    evaluations = stagiaire.evaluations.order_by('-created_at')
    # Calcul des moyennes
    if evaluations.exists():
        avg_realisation = round(sum(e.realisation_projet_score for e in evaluations) / evaluations.count(), 2)
        avg_attitude = round(sum(e.attitude_comportement_score for e in evaluations) / evaluations.count(), 2)
        avg_20 = round(sum(e.score_sur_20 for e in evaluations) / evaluations.count(), 2)
    else:
        avg_realisation = None
        avg_attitude = None
        avg_20 = None
    return render(
        request,
        'stagiaires/details.html',
        {
            'stagiaire': stagiaire,
            'evaluations': evaluations,
            'avg_realisation': avg_realisation,
            'avg_attitude': avg_attitude,
            'avg_20': avg_20,
        },
    )


def acces_refuse(request, exception=None):
    return render(request, 'stagiaires/acces_refuse.html', status=403)
@permission_required('stagiaires.add_stagiaire', raise_exception=True)
def historique_stagiaires(request):
    archives = Stagiaire.objects.filter(archived_at__isnull=False).order_by('-archived_at')
    return render(request, 'stagiaires/historique.html', {'archives': archives})