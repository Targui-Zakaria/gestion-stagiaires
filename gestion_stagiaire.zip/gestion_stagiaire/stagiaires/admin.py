from django.contrib import admin
from .models import Stagiaire, TypeStage, Evaluation, Encadrant

@admin.register(Encadrant)
class EncadrantAdmin(admin.ModelAdmin):
    list_display = ['prenom', 'nom', 'email', 'telephone']
    search_fields = ['prenom', 'nom', 'email']
    list_filter = ['nom']

@admin.register(TypeStage)
class TypeStageAdmin(admin.ModelAdmin):
    list_display = ['nom']
    search_fields = ['nom']

@admin.register(Stagiaire)
class StagiaireAdmin(admin.ModelAdmin):
    list_display = ['prenom', 'nom', 'email', 'encadrant', 'date_debut', 'date_fin', 'ecole']
    list_filter = ['encadrant', 'ecole', 'type_stage', 'date_debut']
    search_fields = ['prenom', 'nom', 'email', 'ecole']
    date_hierarchy = 'date_debut'

@admin.register(Evaluation)
class EvaluationAdmin(admin.ModelAdmin):
    list_display = ['stagiaire', 'evaluator', 'methodologie', 'connaissances_techniques', 'created_at']
    list_filter = ['methodologie', 'connaissances_techniques', 'created_at']
    search_fields = ['stagiaire__prenom', 'stagiaire__nom', 'evaluator__username']
    date_hierarchy = 'created_at'
    fieldsets = (
        ('Informations générales', {
            'fields': ('stagiaire', 'evaluator', 'comment')
        }),
        ('Réalisation du projet', {
            'fields': ('methodologie', 'connaissances_techniques', 'outils_logiciels', 'solutions_problemes', 'objectifs_projet')
        }),
        ('Attitude & comportement', {
            'fields': ('adaptation_determination', 'documentation_recherche', 'contacts_collaborateurs', 'initiatives_creativite', 'expression_idees', 'critiques_corrections')
        }),
    )
