from django import forms
from django.contrib.auth.models import User
from .models import Stagiaire, Evaluation, Encadrant

class StagiaireForm(forms.ModelForm):
    class Meta:
        model = Stagiaire
        fields = ['nom', 'prenom', 'email', 'telephone', 'date_debut', 'date_fin', 'sujet_stage', 'encadrant', 'cin', 'ecole', 'type_stage']
        widgets = {
            'encadrant': forms.Select(attrs={'class': 'form-select'}),
            'date_debut': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'date_fin': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'nom': forms.TextInput(attrs={'class': 'form-control'}),
            'prenom': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telephone': forms.TextInput(attrs={'class': 'form-control'}),
            'sujet_stage': forms.TextInput(attrs={'class': 'form-control'}),
            'cin': forms.TextInput(attrs={'class': 'form-control'}),
            'ecole': forms.TextInput(attrs={'class': 'form-control'}),
            'type_stage': forms.Select(attrs={'class': 'form-select'}),
        }

class EvaluationForm(forms.ModelForm):
    class Meta:
        model = Evaluation
        fields = [
            'methodologie', 'connaissances_techniques', 'outils_logiciels', 'solutions_problemes', 'objectifs_projet',
            'adaptation_determination', 'documentation_recherche', 'contacts_collaborateurs', 
            'initiatives_creativite', 'expression_idees', 'critiques_corrections', 'comment'
        ]
        widgets = {
            'methodologie': forms.Select(attrs={'class': 'form-select'}),
            'connaissances_techniques': forms.Select(attrs={'class': 'form-select'}),
            'outils_logiciels': forms.Select(attrs={'class': 'form-select'}),
            'solutions_problemes': forms.Select(attrs={'class': 'form-select'}),
            'objectifs_projet': forms.Select(attrs={'class': 'form-select'}),
            'adaptation_determination': forms.Select(attrs={'class': 'form-select'}),
            'documentation_recherche': forms.Select(attrs={'class': 'form-select'}),
            'contacts_collaborateurs': forms.Select(attrs={'class': 'form-select'}),
            'initiatives_creativite': forms.Select(attrs={'class': 'form-select'}),
            'expression_idees': forms.Select(attrs={'class': 'form-select'}),
            'critiques_corrections': forms.Select(attrs={'class': 'form-select'}),
            'comment': forms.Textarea(attrs={'class': 'form-control', 'rows': 4}),
        }

class EncadrantForm(forms.ModelForm):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': 'form-control'}),
        help_text=None,
        label='Nom d\'utilisateur'
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': 'form-control'}),
        label='Mot de passe'
    )
    class Meta:
        model = Encadrant
        fields = ['nom', 'prenom', 'email', 'telephone']
        widgets = {
            'nom': forms.TextInput(attrs={'class': 'form-control'}),
            'prenom': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'telephone': forms.TextInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Lors de la modification, ne pas exiger username/password
        if getattr(self.instance, 'pk', None):
            self.fields['username'].required = False
            self.fields['password'].required = False

    def clean_username(self):
        username = self.cleaned_data.get('username')
        # Si on est en mode édition et que le champ n'est pas fourni, ne pas valider l'unicité
        if not username:
            return username
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError("Ce nom d'utilisateur existe déjà.")
        return username