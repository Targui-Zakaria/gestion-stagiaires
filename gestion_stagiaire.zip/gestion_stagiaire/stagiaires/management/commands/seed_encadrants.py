from django.core.management.base import BaseCommand
from django.contrib.auth.models import User, Permission
from stagiaires.models import Encadrant


DEFAULTS = [
    {"prenom": "Achraf", "nom": "", "email": "achraf@example.com", "username": "achraf", "password": "achraf123", "telephone": ""},
    {"prenom": "Rachid", "nom": "", "email": "rachid@example.com", "username": "rachid", "password": "rachid123", "telephone": ""},
    {"prenom": "Ayman",  "nom": "", "email": "ayman@example.com",  "username": "ayman",  "password": "ayman123",  "telephone": ""},
    {"prenom": "Iness",  "nom": "", "email": "iness@example.com",  "username": "iness",  "password": "iness123",  "telephone": ""},
    {"prenom": "Ryad",   "nom": "", "email": "ryad@example.com",   "username": "ryad",   "password": "ryad123",   "telephone": ""},
]


class Command(BaseCommand):
    help = "Seed encadrant profiles and users with default credentials"

    def add_arguments(self, parser):
        parser.add_argument(
            "--purge",
            action="store_true",
            help="Delete all existing encadrants before seeding",
        )

    def handle(self, *args, **options):
        if options.get("purge"):
            Encadrant.objects.all().delete()
            self.stdout.write(self.style.WARNING("All encadrants deleted."))

        try:
            perm = Permission.objects.get(codename='add_evaluation')
        except Permission.DoesNotExist:
            perm = None

        created_count = 0
        for data in DEFAULTS:
            # Ensure user exists
            user, user_created = User.objects.get_or_create(
                username=data["username"],
                defaults={"email": data["email"]}
            )
            if user_created:
                user.set_password(data["password"])
                user.save()
            # attach permission
            if perm and not user.has_perm('stagiaires.add_evaluation'):
                user.user_permissions.add(perm)

            # Ensure encadrant profile exists with matching email
            encadrant, enc_created = Encadrant.objects.get_or_create(
                email=data["email"],
                defaults={
                    "prenom": data["prenom"],
                    "nom": data["nom"] or data["prenom"],
                    "telephone": data.get("telephone") or "",
                }
            )
            if user_created or enc_created:
                created_count += 1

        self.stdout.write(self.style.SUCCESS(f"Seed completed. {created_count} created/updated."))


