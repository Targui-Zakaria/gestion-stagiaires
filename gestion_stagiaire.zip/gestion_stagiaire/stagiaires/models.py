from django.db import models
from django.conf import settings
from django.contrib.auth.models import User
from django.utils import timezone

class Encadrant(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    telephone = models.CharField(max_length=15, blank=True, null=True)

    def __str__(self):
        return f"{self.prenom} {self.nom}"

    def nom_complet(self):
        return f"{self.prenom} {self.nom}"

class TypeStage(models.Model):
    nom = models.CharField(max_length=100)

    def __str__(self):
        return self.nom

class Stagiaire(models.Model):
    nom = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    telephone = models.CharField(max_length=15)
    date_debut = models.DateField()
    date_fin = models.DateField()
    sujet_stage = models.CharField(max_length=255)
    encadrant = models.ForeignKey(Encadrant, on_delete=models.CASCADE, verbose_name="Encadrant")
    cin = models.CharField(max_length=20, verbose_name="CIN", blank=True, null=True)
    ecole = models.CharField(max_length=150, verbose_name="École", blank=True, null=True)
    type_stage = models.ForeignKey(TypeStage, on_delete=models.CASCADE, null=True, blank=True)
    evaluation = models.TextField(blank=True, null=True)
    archived_at = models.DateTimeField(null=True, blank=True)
    
    def archive(self):
        self.archived_at = timezone.now()
        self.save()

    def is_archived(self):
        return self.archived_at is not None
    
    class Meta:
        permissions = [
            ("can_evaluer", "Peut évaluer un stagiaire"),
        ]
    
    def __str__(self):
        return f"{self.prenom} {self.nom}"

class Evaluation(models.Model):
    SATISFACTION_CHOICES = [
        (5, 'Très satisfait'),
        (4, 'Satisfait'),
        (3, 'Ni satisfait, ni insatisfait'),
        (2, 'Peu satisfait'),
        (1, 'Pas du tout satisfait'),
    ]
    
    stagiaire = models.ForeignKey(Stagiaire, related_name='evaluations', on_delete=models.CASCADE)
    evaluator = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Section 1: REALISATION DU PROJET
    methodologie = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Méthodologie adaptée")
    connaissances_techniques = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Connaissances techniques")
    outils_logiciels = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Utilisation des outils")
    solutions_problemes = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Solutions adaptées")
    objectifs_projet = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Atteinte des objectifs")
    
    # Section 2: ATTITUDE & COMPORTEMENT
    adaptation_determination = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Adaptation et détermination")
    documentation_recherche = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Documentation et recherche")
    contacts_collaborateurs = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Contacts avec collaborateurs")
    initiatives_creativite = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Initiatives et créativité")
    expression_idees = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Expression des idées")
    critiques_corrections = models.PositiveSmallIntegerField(choices=SATISFACTION_CHOICES, verbose_name="Critiques constructives")
    
    comment = models.TextField(blank=True, verbose_name="Commentaire général")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Évaluation {self.stagiaire} - {self.created_at.strftime('%d/%m/%Y')}"

    @property
    def realisation_projet_score(self):
        # Moyenne des critères de réalisation du projet (5 champs)
        scores = [
            self.methodologie,
            self.connaissances_techniques,
            self.outils_logiciels,
            self.solutions_problemes,
            self.objectifs_projet,
        ]
        return round(sum(scores) / len(scores), 2)

    @property
    def attitude_comportement_score(self):
        # Moyenne des critères d'attitude & comportement (6 champs)
        scores = [
            self.adaptation_determination,
            self.documentation_recherche,
            self.contacts_collaborateurs,
            self.initiatives_creativite,
            self.expression_idees,
            self.critiques_corrections,
        ]
        return round(sum(scores) / len(scores), 2)

    @property
    def score_sur_20(self):
        # Moyenne de tous les critères (11) ramenée sur 20
        scores = [
            self.methodologie,
            self.connaissances_techniques,
            self.outils_logiciels,
            self.solutions_problemes,
            self.objectifs_projet,
            self.adaptation_determination,
            self.documentation_recherche,
            self.contacts_collaborateurs,
            self.initiatives_creativite,
            self.expression_idees,
            self.critiques_corrections,
        ]
        avg_5 = sum(scores) / len(scores)
        return round(avg_5 * 4, 2)
