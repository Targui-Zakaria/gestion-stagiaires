"""
URL configuration for gestion_stagiaire project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from stagiaires import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home_redirect, name='home'),
    path('admin-dashboard/', views.dashboard_admin, name='dashboard_admin'),
    path('encadrant-dashboard/', views.dashboard_encadrant, name='dashboard_encadrant'),
    path('liste/', views.liste_stagiaires, name='liste_stagiaires'),
    path('stagiaire/<int:id>/', views.details_stagiaire, name='details_stagiaire'),
    path('stagiaire/<int:id>/evaluer/', views.evaluer_stagiaire, name='evaluer_stagiaire'),
    path('evaluation/<int:id>/', views.fiche_evaluation, name='fiche_evaluation'),
    path('evaluation/<int:id>/pdf/', views.export_evaluation_pdf, name='export_evaluation_pdf'),
    path('ajouter/', views.ajouter_stagiaire, name='ajouter_stagiaire'),
    path('modifier/<int:id>/', views.modifier_stagiaire, name='modifier_stagiaire'),
    path('supprimer/<int:id>/', views.supprimer_stagiaire, name='supprimer_stagiaire'),
    path('connexion/', views.connexion_view, name='connexion'),
    path('connexion/admin/', views.connexion_admin, name='connexion_admin'),
    path('connexion/encadrant/', views.connexion_encadrant, name='connexion_encadrant'),
    path('deconnexion/', views.deconnexion_view, name='deconnexion'),
    path('acces-refuse/', views.acces_refuse, name='page_acces_refuse'),
    path('historique/', views.historique_stagiaires, name='historique_stagiaires'),
    
    # URLs pour la gestion des encadrants
    path('encadrants/', views.liste_encadrants, name='liste_encadrants'),
    path('encadrant/ajouter/', views.ajouter_encadrant, name='ajouter_encadrant'),
    path('encadrant/modifier/<int:id>/', views.modifier_encadrant, name='modifier_encadrant'),
    path('encadrant/supprimer/<int:id>/', views.supprimer_encadrant, name='supprimer_encadrant'),
]

# Custom error handlers
handler403 = 'stagiaires.views.acces_refuse'
